//
//  ThreeRingControl.h
//  ThreeRingControl
//
//  Created by Leonardo Saganski on 22/11/16.
//  Copyright © 2016 Leonardo Saganski. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ThreeRingControl.
FOUNDATION_EXPORT double ThreeRingControlVersionNumber;

//! Project version string for ThreeRingControl.
FOUNDATION_EXPORT const unsigned char ThreeRingControlVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ThreeRingControl/PublicHeader.h>


